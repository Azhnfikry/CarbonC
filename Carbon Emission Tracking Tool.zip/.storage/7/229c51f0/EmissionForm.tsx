import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { ACTIVITY_TYPES } from '@/lib/emissionFactors';
import { calculateEmissions } from '@/lib/emissionCalculations';
import { EmissionEntry } from '@/types/emission';
import { Plus } from 'lucide-react';

interface EmissionFormProps {
  onAddEntry: (entry: EmissionEntry) => void;
}

export default function EmissionForm({ onAddEntry }: EmissionFormProps) {
  const [selectedActivityType, setSelectedActivityType] = useState('');
  const [activityData, setActivityData] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const activityType = ACTIVITY_TYPES.find(at => at.id === selectedActivityType);
    if (!activityType || !activityData) return;

    const activityValue = parseFloat(activityData);
    const co2Equivalent = calculateEmissions(activityValue, activityType.emissionFactor);

    const entry: EmissionEntry = {
      id: Date.now().toString(),
      date,
      category: activityType.category,
      scope: activityType.scope,
      activityType: activityType.name,
      activityData: activityValue,
      unit: activityType.unit,
      emissionFactor: activityType.emissionFactor,
      co2Equivalent,
      description: description || undefined
    };

    onAddEntry(entry);
    
    // Reset form
    setSelectedActivityType('');
    setActivityData('');
    setDescription('');
  };

  const selectedActivity = ACTIVITY_TYPES.find(at => at.id === selectedActivityType);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Plus className="h-5 w-5" />
          Add Emission Entry
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="activity-type">Activity Type</Label>
              <Select value={selectedActivityType} onValueChange={setSelectedActivityType} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select activity type" />
                </SelectTrigger>
                <SelectContent>
                  {ACTIVITY_TYPES.map((activity) => (
                    <SelectItem key={activity.id} value={activity.id}>
                      {activity.name} ({activity.unit})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {selectedActivity && (
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">
                <strong>{selectedActivity.name}</strong> - {selectedActivity.description}
              </p>
              <p className="text-sm text-muted-foreground">
                Emission Factor: {selectedActivity.emissionFactor} kg CO₂e per {selectedActivity.unit}
              </p>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="activity-data">
              Activity Data {selectedActivity && `(${selectedActivity.unit})`}
            </Label>
            <Input
              id="activity-data"
              type="number"
              step="0.01"
              min="0"
              value={activityData}
              onChange={(e) => setActivityData(e.target.value)}
              placeholder={selectedActivity ? `Enter amount in ${selectedActivity.unit}` : 'Select activity type first'}
              required
              disabled={!selectedActivity}
            />
          </div>

          {selectedActivity && activityData && (
            <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm font-medium text-green-800">
                Calculated Emissions: {calculateEmissions(parseFloat(activityData), selectedActivity.emissionFactor).toFixed(2)} kg CO₂e
              </p>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Additional notes about this emission entry"
              rows={2}
            />
          </div>

          <Button type="submit" className="w-full" disabled={!selectedActivityType || !activityData}>
            Add Emission Entry
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}