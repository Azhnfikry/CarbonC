import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { EmissionEntry } from '@/types/emission';
import { formatEmissions } from '@/lib/emissionCalculations';
import { SCOPE_LABELS, CATEGORY_LABELS } from '@/lib/emissionFactors';
import { Trash2, FileText } from 'lucide-react';

interface EmissionTableProps {
  entries: EmissionEntry[];
  onDeleteEntry: (id: string) => void;
}

export default function EmissionTable({ entries, onDeleteEntry }: EmissionTableProps) {
  const [sortBy, setSortBy] = useState<'date' | 'emissions'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const sortedEntries = [...entries].sort((a, b) => {
    if (sortBy === 'date') {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
    } else {
      return sortOrder === 'asc' 
        ? a.co2Equivalent - b.co2Equivalent 
        : b.co2Equivalent - a.co2Equivalent;
    }
  });

  const handleSort = (field: 'date' | 'emissions') => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  const getScopeColor = (scope: string) => {
    switch (scope) {
      case 'scope1': return 'bg-red-100 text-red-800';
      case 'scope2': return 'bg-orange-100 text-orange-800';
      case 'scope3': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (entries.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Emission Entries
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No emission entries yet. Add your first entry above to get started.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Emission Entries ({entries.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    onClick={() => handleSort('date')}
                    className="h-auto p-0 font-semibold"
                  >
                    Date {sortBy === 'date' && (sortOrder === 'asc' ? '↑' : '↓')}
                  </Button>
                </TableHead>
                <TableHead>Activity</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Scope</TableHead>
                <TableHead>Activity Data</TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    onClick={() => handleSort('emissions')}
                    className="h-auto p-0 font-semibold"
                  >
                    Emissions {sortBy === 'emissions' && (sortOrder === 'asc' ? '↑' : '↓')}
                  </Button>
                </TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedEntries.map((entry) => (
                <TableRow key={entry.id}>
                  <TableCell className="font-medium">
                    {new Date(entry.date).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{entry.activityType}</div>
                      {entry.description && (
                        <div className="text-sm text-muted-foreground">
                          {entry.description}
                        </div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {CATEGORY_LABELS[entry.category]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={getScopeColor(entry.scope)}>
                      {SCOPE_LABELS[entry.scope]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {entry.activityData.toFixed(2)} {entry.unit}
                  </TableCell>
                  <TableCell className="font-medium">
                    {formatEmissions(entry.co2Equivalent)}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onDeleteEntry(entry.id)}
                      className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}