import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import EmissionForm from '@/components/EmissionForm';
import EmissionSummaryComponent from '@/components/EmissionSummary';
import EmissionChart from '@/components/EmissionChart';
import EmissionTable from '@/components/EmissionTable';
import { EmissionEntry } from '@/types/emission';
import { calculateSummary } from '@/lib/emissionCalculations';
import { Download, Leaf, BarChart3, FileText, Plus } from 'lucide-react';
import { toast } from 'sonner';

const STORAGE_KEY = 'carbon-accounting-entries';

export default function CarbonAccountingDashboard() {
  const [entries, setEntries] = useState<EmissionEntry[]>([]);
  const [activeTab, setActiveTab] = useState('overview');

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedEntries = localStorage.getItem(STORAGE_KEY);
    if (savedEntries) {
      try {
        setEntries(JSON.parse(savedEntries));
      } catch (error) {
        console.error('Error loading saved entries:', error);
      }
    }
  }, []);

  // Save data to localStorage whenever entries change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  }, [entries]);

  const handleAddEntry = (entry: EmissionEntry) => {
    setEntries(prev => [...prev, entry]);
    toast.success('Emission entry added successfully!');
  };

  const handleDeleteEntry = (id: string) => {
    setEntries(prev => prev.filter(entry => entry.id !== id));
    toast.success('Emission entry deleted successfully!');
  };

  const handleExportData = () => {
    const summary = calculateSummary(entries);
    const exportData = {
      summary,
      entries,
      exportDate: new Date().toISOString(),
      totalEntries: entries.length
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `carbon-emissions-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success('Data exported successfully!');
  };

  const summary = calculateSummary(entries);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-600 rounded-lg">
                <Leaf className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">
                  Carbon Accounting Dashboard
                </h1>
                <p className="text-gray-600">
                  Track and manage your organization's GHG emissions
                </p>
              </div>
            </div>
            
            {entries.length > 0 && (
              <Button onClick={handleExportData} variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Export Data
              </Button>
            )}
          </div>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview" className="gap-2">
              <BarChart3 className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="add-entry" className="gap-2">
              <Plus className="h-4 w-4" />
              Add Entry
            </TabsTrigger>
            <TabsTrigger value="charts" className="gap-2">
              <BarChart3 className="h-4 w-4" />
              Charts
            </TabsTrigger>
            <TabsTrigger value="entries" className="gap-2">
              <FileText className="h-4 w-4" />
              All Entries
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {entries.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Leaf className="h-16 w-16 mx-auto mb-4 text-green-600 opacity-50" />
                  <h3 className="text-xl font-semibold mb-2">Welcome to Carbon Accounting</h3>
                  <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                    Start tracking your organization's greenhouse gas emissions by adding your first emission entry.
                  </p>
                  <Button onClick={() => setActiveTab('add-entry')} className="gap-2">
                    <Plus className="h-4 w-4" />
                    Add Your First Entry
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <EmissionSummaryComponent summary={summary} />
            )}
          </TabsContent>

          {/* Add Entry Tab */}
          <TabsContent value="add-entry">
            <EmissionForm onAddEntry={handleAddEntry} />
          </TabsContent>

          {/* Charts Tab */}
          <TabsContent value="charts">
            {entries.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <BarChart3 className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-xl font-semibold mb-2">No Data to Display</h3>
                  <p className="text-muted-foreground mb-6">
                    Add some emission entries to see charts and visualizations.
                  </p>
                  <Button onClick={() => setActiveTab('add-entry')} variant="outline">
                    Add Entries
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <EmissionChart summary={summary} />
            )}
          </TabsContent>

          {/* Entries Tab */}
          <TabsContent value="entries">
            <EmissionTable entries={entries} onDeleteEntry={handleDeleteEntry} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}