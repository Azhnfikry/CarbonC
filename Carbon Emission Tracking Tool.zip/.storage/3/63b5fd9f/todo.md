# Carbon Accounting GHG Emission Software - MVP

## Core Features to Implement:
1. **Dashboard Overview** - Main page showing emission summaries and key metrics
2. **Emission Data Entry** - Form to input emission data by category (Scope 1, 2, 3)
3. **Emission Categories** - Predefined categories like energy, transport, waste, etc.
4. **Calculations** - Automatic GHG emission calculations using emission factors
5. **Data Visualization** - Charts showing emissions by category, time period
6. **Simple Reporting** - Basic emission reports and summaries

## Files to Create:
1. `src/pages/Index.tsx` - Main dashboard page (rewrite)
2. `src/components/EmissionForm.tsx` - Data entry form component
3. `src/components/EmissionChart.tsx` - Chart visualization component
4. `src/components/EmissionSummary.tsx` - Summary cards component
5. `src/components/EmissionTable.tsx` - Data table component
6. `src/lib/emissionFactors.ts` - Emission factors and calculation logic
7. `src/lib/emissionCalculations.ts` - Calculation utilities
8. `src/types/emission.ts` - TypeScript types for emission data

## Data Structure:
- Emission entries with category, activity data, emission factor, CO2 equivalent
- Categories: Energy, Transportation, Waste, Water, etc.
- Scopes: Scope 1 (Direct), Scope 2 (Indirect Energy), Scope 3 (Other Indirect)

## Tech Stack:
- React + TypeScript
- Shadcn/ui components
- Recharts for data visualization
- Local storage for data persistence