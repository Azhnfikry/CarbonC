import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { EmissionSummary } from '@/types/emission';
import { formatEmissions } from '@/lib/emissionCalculations';
import { SCOPE_LABELS, CATEGORY_LABELS } from '@/lib/emissionFactors';
import { Leaf, Zap, Car, Trash2 } from 'lucide-react';

interface EmissionSummaryProps {
  summary: EmissionSummary;
}

export default function EmissionSummaryComponent({ summary }: EmissionSummaryProps) {
  const scopeData = [
    { 
      label: SCOPE_LABELS.scope1, 
      value: summary.scope1, 
      color: 'bg-red-500',
      icon: Car
    },
    { 
      label: SCOPE_LABELS.scope2, 
      value: summary.scope2, 
      color: 'bg-orange-500',
      icon: Zap
    },
    { 
      label: SCOPE_LABELS.scope3, 
      value: summary.scope3, 
      color: 'bg-blue-500',
      icon: Trash2
    }
  ];

  const topCategories = Object.entries(summary.byCategory)
    .filter(([_, value]) => value > 0)
    .sort(([_, a], [__, b]) => b - a)
    .slice(0, 4);

  return (
    <div className="space-y-6">
      {/* Total Emissions */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <Leaf className="h-5 w-5 text-green-600" />
            Total GHG Emissions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-green-600">
            {formatEmissions(summary.totalEmissions)}
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            Carbon dioxide equivalent
          </p>
        </CardContent>
      </Card>

      {/* Scope Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {scopeData.map((scope) => {
          const Icon = scope.icon;
          return (
            <Card key={scope.label}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      {scope.label}
                    </p>
                    <p className="text-xl font-bold">
                      {formatEmissions(scope.value)}
                    </p>
                  </div>
                  <div className={`p-2 rounded-full ${scope.color}`}>
                    <Icon className="h-4 w-4 text-white" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${scope.color}`}
                      style={{
                        width: summary.totalEmissions > 0 
                          ? `${(scope.value / summary.totalEmissions) * 100}%` 
                          : '0%'
                      }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {summary.totalEmissions > 0 
                      ? `${((scope.value / summary.totalEmissions) * 100).toFixed(1)}% of total`
                      : '0% of total'
                    }
                  </p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Category Breakdown */}
      {topCategories.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Emissions by Category</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topCategories.map(([category, value]) => (
                <div key={category} className="flex items-center justify-between">
                  <span className="text-sm font-medium">
                    {CATEGORY_LABELS[category as keyof typeof CATEGORY_LABELS]}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">
                      {formatEmissions(value)}
                    </span>
                    <div className="w-20 bg-gray-200 rounded-full h-2">
                      <div
                        className="h-2 bg-green-500 rounded-full"
                        style={{
                          width: summary.totalEmissions > 0 
                            ? `${(value / summary.totalEmissions) * 100}%` 
                            : '0%'
                        }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}