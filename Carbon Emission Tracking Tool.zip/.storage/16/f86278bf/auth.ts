export interface User {
  id: string;
  username: string;
  companyName: string;
  createdAt: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
}

export interface LoginCredentials {
  username: string;
  companyName: string;
  password: string;
}

export interface RegisterData {
  username: string;
  companyName: string;
  password: string;
  confirmPassword: string;
}