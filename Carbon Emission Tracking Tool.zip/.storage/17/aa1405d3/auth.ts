import { User, LoginCredentials, RegisterData } from '@/types/auth';

const USERS_STORAGE_KEY = 'carbon-accounting-users';
const CURRENT_USER_KEY = 'carbon-accounting-current-user';

export class AuthService {
  static getUsers(): Record<string, { user: User; passwordHash: string }> {
    const users = localStorage.getItem(USERS_STORAGE_KEY);
    return users ? JSON.parse(users) : {};
  }

  static saveUsers(users: Record<string, { user: User; passwordHash: string }>) {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  }

  static hashPassword(password: string): string {
    // Simple hash function for demo purposes (in production, use proper hashing)
    let hash = 0;
    for (let i = 0; i < password.length; i++) {
      const char = password.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return hash.toString();
  }

  static generateUserId(username: string, companyName: string): string {
    return `${companyName.toLowerCase().replace(/\s+/g, '-')}-${username.toLowerCase()}`;
  }

  static register(data: RegisterData): { success: boolean; message: string; user?: User } {
    const { username, companyName, password, confirmPassword } = data;

    if (!username || !companyName || !password) {
      return { success: false, message: 'All fields are required' };
    }

    if (password !== confirmPassword) {
      return { success: false, message: 'Passwords do not match' };
    }

    if (password.length < 6) {
      return { success: false, message: 'Password must be at least 6 characters long' };
    }

    const userId = this.generateUserId(username, companyName);
    const users = this.getUsers();

    if (users[userId]) {
      return { success: false, message: 'User already exists for this company' };
    }

    const user: User = {
      id: userId,
      username,
      companyName,
      createdAt: new Date().toISOString()
    };

    users[userId] = {
      user,
      passwordHash: this.hashPassword(password)
    };

    this.saveUsers(users);
    this.setCurrentUser(user);

    return { success: true, message: 'Registration successful', user };
  }

  static login(credentials: LoginCredentials): { success: boolean; message: string; user?: User } {
    const { username, companyName, password } = credentials;

    if (!username || !companyName || !password) {
      return { success: false, message: 'All fields are required' };
    }

    const userId = this.generateUserId(username, companyName);
    const users = this.getUsers();
    const userRecord = users[userId];

    if (!userRecord) {
      return { success: false, message: 'User not found' };
    }

    const passwordHash = this.hashPassword(password);
    if (userRecord.passwordHash !== passwordHash) {
      return { success: false, message: 'Invalid password' };
    }

    this.setCurrentUser(userRecord.user);
    return { success: true, message: 'Login successful', user: userRecord.user };
  }

  static logout(): void {
    localStorage.removeItem(CURRENT_USER_KEY);
  }

  static getCurrentUser(): User | null {
    const user = localStorage.getItem(CURRENT_USER_KEY);
    return user ? JSON.parse(user) : null;
  }

  static setCurrentUser(user: User): void {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  }

  static isAuthenticated(): boolean {
    return this.getCurrentUser() !== null;
  }

  static getCompanyStorageKey(userId: string, key: string): string {
    return `${key}-${userId}`;
  }
}