import { ActivityType, EmissionCategory, EmissionScope } from '@/types/emission';

// Emission factors in kg CO2e per unit
export const ACTIVITY_TYPES: ActivityType[] = [
  // Energy - Scope 2
  {
    id: 'electricity-grid',
    name: 'Grid Electricity',
    category: 'energy',
    scope: 'scope2',
    unit: 'kWh',
    emissionFactor: 0.758, // kg CO2e per kWh (updated from 0.5)
    description: 'Electricity consumption from the grid'
  },
  {
    id: 'natural-gas',
    name: 'Natural Gas',
    category: 'energy',
    scope: 'scope1',
    unit: 'm³',
    emissionFactor: 2.0, // kg CO2e per m³
    description: 'Natural gas consumption for heating/cooking'
  },
  
  // Transportation - Scope 1 & 3
  {
    id: 'gasoline-vehicle',
    name: 'Gasoline Vehicle',
    category: 'transportation',
    scope: 'scope1',
    unit: 'liters',
    emissionFactor: 2.31, // kg CO2e per liter (updated from 2.3)
    description: 'Company-owned gasoline vehicles'
  },
  {
    id: 'diesel-vehicle',
    name: 'Diesel Vehicle',
    category: 'transportation',
    scope: 'scope1',
    unit: 'liters',
    emissionFactor: 2.7, // kg CO2e per liter
    description: 'Company-owned diesel vehicles'
  },
  {
    id: 'air-travel',
    name: 'Air Travel',
    category: 'transportation',
    scope: 'scope3',
    unit: 'km',
    emissionFactor: 0.25, // kg CO2e per passenger-km
    description: 'Business air travel'
  },
  
  // Waste - Scope 3
  {
    id: 'general-waste',
    name: 'General Waste',
    category: 'waste',
    scope: 'scope3',
    unit: 'kg',
    emissionFactor: 0.5, // kg CO2e per kg
    description: 'General waste sent to landfill'
  },
  {
    id: 'recycling',
    name: 'Recycling',
    category: 'waste',
    scope: 'scope3',
    unit: 'kg',
    emissionFactor: 0.1, // kg CO2e per kg
    description: 'Recyclable materials'
  },
  
  // Water - Scope 3
  {
    id: 'water-supply',
    name: 'Water Supply',
    category: 'water',
    scope: 'scope3',
    unit: 'm³',
    emissionFactor: 0.3, // kg CO2e per m³
    description: 'Municipal water supply'
  },
  
  // Materials - Scope 3
  {
    id: 'paper',
    name: 'Paper',
    category: 'materials',
    scope: 'scope3',
    unit: 'kg',
    emissionFactor: 1.8, // kg CO2e per kg
    description: 'Office paper consumption'
  }
];

export const CATEGORY_LABELS: Record<EmissionCategory, string> = {
  energy: 'Energy',
  transportation: 'Transportation',
  waste: 'Waste',
  water: 'Water',
  materials: 'Materials',
  other: 'Other'
};

export const SCOPE_LABELS: Record<EmissionScope, string> = {
  scope1: 'Scope 1 (Direct)',
  scope2: 'Scope 2 (Indirect Energy)',
  scope3: 'Scope 3 (Other Indirect)'
};

export const SCOPE_COLORS = {
  scope1: '#ef4444', // red
  scope2: '#f97316', // orange
  scope3: '#3b82f6'  // blue
};