import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { EmissionSummary } from '@/types/emission';
import { SCOPE_COLORS, CATEGORY_LABELS } from '@/lib/emissionFactors';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

interface EmissionChartProps {
  summary: EmissionSummary;
}

export default function EmissionChart({ summary }: EmissionChartProps) {
  // Scope data for pie chart
  const scopeData = [
    { name: 'Scope 1', value: summary.scope1, color: SCOPE_COLORS.scope1 },
    { name: 'Scope 2', value: summary.scope2, color: SCOPE_COLORS.scope2 },
    { name: 'Scope 3', value: summary.scope3, color: SCOPE_COLORS.scope3 }
  ].filter(item => item.value > 0);

  // Category data for bar chart
  const categoryData = Object.entries(summary.byCategory)
    .filter(([_, value]) => value > 0)
    .map(([category, value]) => ({
      category: CATEGORY_LABELS[category as keyof typeof CATEGORY_LABELS],
      emissions: value
    }))
    .sort((a, b) => b.emissions - a.emissions);

  // Monthly trend data
  const monthlyData = Object.entries(summary.byMonth)
    .map(([month, value]) => ({
      month: new Date(month + '-01').toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      emissions: value
    }))
    .sort((a, b) => a.month.localeCompare(b.month));

  return (
    <div className="space-y-6">
      {/* Scope Distribution */}
      {scopeData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Emissions by Scope</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={scopeData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {scopeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: number) => [`${value.toFixed(2)} kg CO₂e`, 'Emissions']}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Category Breakdown */}
      {categoryData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Emissions by Category</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="category" 
                    angle={-45}
                    textAnchor="end"
                    height={80}
                  />
                  <YAxis />
                  <Tooltip 
                    formatter={(value: number) => [`${value.toFixed(2)} kg CO₂e`, 'Emissions']}
                  />
                  <Bar dataKey="emissions" fill="#22c55e" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Monthly Trend */}
      {monthlyData.length > 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Monthly Emissions Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value: number) => [`${value.toFixed(2)} kg CO₂e`, 'Emissions']}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="emissions" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={{ fill: '#3b82f6' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}