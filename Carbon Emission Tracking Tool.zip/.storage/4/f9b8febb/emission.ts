export interface EmissionEntry {
  id: string;
  date: string;
  category: EmissionCategory;
  scope: EmissionScope;
  activityType: string;
  activityData: number;
  unit: string;
  emissionFactor: number;
  co2Equivalent: number;
  description?: string;
}

export type EmissionCategory = 
  | 'energy'
  | 'transportation'
  | 'waste'
  | 'water'
  | 'materials'
  | 'other';

export type EmissionScope = 'scope1' | 'scope2' | 'scope3';

export interface EmissionSummary {
  totalEmissions: number;
  scope1: number;
  scope2: number;
  scope3: number;
  byCategory: Record<EmissionCategory, number>;
  byMonth: Record<string, number>;
}

export interface ActivityType {
  id: string;
  name: string;
  category: EmissionCategory;
  scope: EmissionScope;
  unit: string;
  emissionFactor: number;
  description: string;
}