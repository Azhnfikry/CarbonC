import { EmissionEntry, EmissionSummary, EmissionCategory } from '@/types/emission';

export function calculateEmissions(activityData: number, emissionFactor: number): number {
  return activityData * emissionFactor;
}

export function calculateSummary(entries: EmissionEntry[]): EmissionSummary {
  const summary: EmissionSummary = {
    totalEmissions: 0,
    scope1: 0,
    scope2: 0,
    scope3: 0,
    byCategory: {
      energy: 0,
      transportation: 0,
      waste: 0,
      water: 0,
      materials: 0,
      other: 0
    },
    byMonth: {}
  };

  entries.forEach(entry => {
    const emissions = entry.co2Equivalent;
    
    // Total emissions
    summary.totalEmissions += emissions;
    
    // By scope
    summary[entry.scope] += emissions;
    
    // By category
    summary.byCategory[entry.category] += emissions;
    
    // By month
    const month = entry.date.substring(0, 7); // YYYY-MM format
    summary.byMonth[month] = (summary.byMonth[month] || 0) + emissions;
  });

  return summary;
}

export function formatEmissions(value: number): string {
  if (value >= 1000) {
    return `${(value / 1000).toFixed(2)} t CO₂e`;
  }
  return `${value.toFixed(2)} kg CO₂e`;
}

export function getEmissionColor(scope: string): string {
  switch (scope) {
    case 'scope1': return '#ef4444';
    case 'scope2': return '#f97316';
    case 'scope3': return '#3b82f6';
    default: return '#6b7280';
  }
}